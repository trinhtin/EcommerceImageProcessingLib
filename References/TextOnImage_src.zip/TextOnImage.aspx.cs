using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace TextOnImage
{
	public class TextOnImage : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			//Load the Image to be written on.
			Bitmap bitMapImage = new System.Drawing.Bitmap( Server.MapPath("dallen.jpg" )  );
			Graphics graphicImage = Graphics.FromImage( bitMapImage );

			//Smooth graphics is nice.
			graphicImage.SmoothingMode = SmoothingMode.AntiAlias;

			//I am drawing a oval around my text.
			graphicImage.DrawArc(new Pen(Color.Red, 3), 90, 235, 150, 50, 0, 360);

			//Write your text.
			graphicImage.DrawString( "That's my boy!", new Font("Arial", 12,FontStyle.Bold ), SystemBrushes.WindowText, new Point( 100, 250 ) );

			//Set the content type
			Response.ContentType="image/jpeg";

			//Save the new image to the response output stream.
			bitMapImage.Save(Response.OutputStream, ImageFormat.Jpeg);

			//Clean house.
			graphicImage.Dispose();
			bitMapImage.Dispose();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
